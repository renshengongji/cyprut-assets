## **Cyprut Launcher 1.1.1**

## Installation
1. Extract `Launcher.exe` in the game root or choose the game folder from the Settings tab
4. Use the Extensions tab to install or manage BepInEx and Cyprut plugins
5. Use the Launch tab to start the game.

## Diagnostics
Use the Diagnostics tab to export an encrypted report when troubleshooting
The launcher log is stored at:`Cyprut\launcher\log.txt`

## Contact
- Developer email: `renshengongji@qq.com`
- Discord: `renshengongji`
