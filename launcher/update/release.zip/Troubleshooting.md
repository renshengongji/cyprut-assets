﻿## 1. Verify the game path
The game path must contains:
- `Pure Badminton.exe`
- `build_version.txt`

Don't forgot save your settings
