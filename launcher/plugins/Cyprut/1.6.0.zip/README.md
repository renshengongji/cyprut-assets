Pure Badminton Mod Menu

## Supported Game Version
- **Pure Badminton 1.3.2**

---

## Installation Steps

1. **Install BepInEx 5.x (Mono)**  
   - Download the appropriate release from the [official BepInEx repository](https://github.com/BepInEx/BepInEx/releases)
   - (Please refer the official install tutorial) Extract the archive and copy **all files** into the game root folder (where the `Pure Badminton.exe` is located)

2. **Initialize BepInEx**  
   - Launch the game once. This will create the `BepInEx/plugins` folder automatically

3. **Install the Mod Menu**  
   - Extract the mod menu archive. Drag the `Cyprut` folder into `BepInEx/plugins`

4. **Open the Menu In-Game**  
   - Press the **Insert** key while playing to toggle the mod menu

---

## Verification
- If everything is correct, a pop‑up notification will appear when the game starts
- If you don't see the notification or the game crashes, refer to the [Troubleshooting Guide](Troubleshooting.md).

---

## Custom Font (Optional)
- Place your own `.ttf` font file at `BepInEx\config\Cyprut\userdata\font.ttf`
  (Create the `Cyprut` folder inside `config` if it doesn't exist)

---

## Contact
- Developer email: `renshengongji@qq.com` \ `renshengongji (discord)`